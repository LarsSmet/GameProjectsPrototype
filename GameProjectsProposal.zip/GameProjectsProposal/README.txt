Make it through the village scattered with zombies to get to the altar in the pyramid and get rid of Osiris' curse.

Controls:
WASD movement
RMB; fast forward a zombie's lifetime, effectually killing him (ranged)
LMB; sword attack 
SHIFT; dash forward
A; time freeze: create dome in which time freezes exept for the player, player attacks will be executed when time freeze is finished
E; time rewind: tp to position 3sec ago
